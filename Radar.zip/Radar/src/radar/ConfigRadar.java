/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package radar;

public class ConfigRadar {
    public float frequencia, limiteVelocidade;

    public ConfigRadar(float frequencia, float limiteVelocidade) {
        this.frequencia = frequencia;
        this.limiteVelocidade = limiteVelocidade;
    }

    @Override
    public String toString() {
        return "ConfigRadar{" + "frequencia=" + frequencia + ", limiteVelocidade=" + limiteVelocidade + '}';
    }
    
    
}
