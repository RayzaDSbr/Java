/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package radar;

import java.util.Scanner;

/**
 *
 * Gabriel Gustavo Cavalcante Prevedel | RA: 00355045;
 * Marcela Costa dos Santos | RA: 00354653;
 * Matheus Abrahão Massoni | RA: 00353435;
 * Pedro Gabriel Selan Lacerda | RA: 00354527;
 * Rayza Gomes Batista | RA: 00354677;
 * Ryan Silva de Oliveira | RA: 00355025;
 * Tulio Perdigão de Castro | RA: 00353465;
 */
public class Radar {

 
    public static void main(String[] args) {
    Scanner scan = new Scanner ( System.in );
         
      
        System.out.println("Informe a frequência do carro: ");
        float frequencia = scan.nextFloat();
        
        System.out.println("Informe o limite de velociade: ");
        float limiteVelocidade = scan.nextFloat();
        
        ConfigRadar carro1;
        carro1 = new ConfigRadar(frequencia, limiteVelocidade);
       
       System.out.println(carro1.toString());
    }
    
}
