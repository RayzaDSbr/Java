/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package emprestimojava;

public class EmprestimoConfig {
    //Variaveis
    public float taxa, valor;
    public int meses;

    public EmprestimoConfig(float taxa, float valor, int meses) {
        this.taxa = taxa;
        this.valor = valor;
        this.meses = meses;   
    }

    public void calcular(){
        
     double prestacao;
     double taxa1 = taxa / 100;
     
     if (taxa1 == 0){
         prestacao = valor / meses;
     }else{
         prestacao = valor * taxa1 * Math.pow(1 + taxa1, meses) / (Math.pow(1 + taxa1, valor) - 1);
     }
    
     
     System.out.printf("Prestação: R$ %.5f\n", prestacao);
    }
    
   
    
    
    
    
}
