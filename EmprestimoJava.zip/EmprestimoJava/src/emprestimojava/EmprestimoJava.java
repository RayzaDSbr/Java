/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package emprestimojava;

import java.util.Scanner;

/**
 *
 * Rayza Gomes Batista de Siqueira | RA: 00354677;
 
 */
public class EmprestimoJava {

    public static void main(String[] args) {
        Scanner scan = new Scanner ( System.in );
         
      
        System.out.println("Informe o valor da prestação: ");
        float valor = scan.nextFloat();
        
        System.out.println("Informe a taxa mensal: ");
        float taxa = scan.nextFloat();
        
        System.out.println("Informe o tempo em meses: ");
        int meses = (int) scan.nextFloat();
        
        EmprestimoConfig E1;
        E1 = new EmprestimoConfig(valor, taxa, meses);
        E1.calcular();
    }
    
}
