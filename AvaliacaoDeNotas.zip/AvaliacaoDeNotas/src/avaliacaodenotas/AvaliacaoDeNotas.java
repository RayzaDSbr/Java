/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package avaliacaodenotas;

import java.util.Scanner;

/**
 *
 * @author rayza
 */
public class AvaliacaoDeNotas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner ( System.in );
         
       
        
        System.out.println("Digite a primeira nota do aluno: ");
        float n1 = scan.nextFloat();
        
        System.out.println("Digite a segunda nota do aluno: ");
        float n2 = scan.nextFloat();
        
        System.out.println("Digite a terceira nota do aluno: ");
        float n3 = scan.nextFloat();
        
        System.out.println("Digite a quarta nota do aluno: ");
        float n4 = scan.nextFloat();
        
       Notas a1;
       a1 = new Notas(n1,n2,n3,n4);
       
       System.out.println(a1.toString());
  
    }
    
}
